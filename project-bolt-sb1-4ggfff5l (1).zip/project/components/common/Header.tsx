import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, StatusBar, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Bell, Search } from 'lucide-react-native';

interface HeaderProps {
  title: string;
  showNotification?: boolean;
  showSearch?: boolean;
  onNotificationPress?: () => void;
  onSearchPress?: () => void;
}

export default function Header({ 
  title, 
  showNotification = true, 
  showSearch = true,
  onNotificationPress,
  onSearchPress,
}: HeaderProps) {
  const insets = useSafeAreaInsets();
  
  return (
    <View style={[
      styles.container, 
      { paddingTop: Platform.OS === 'ios' ? insets.top : StatusBar.currentHeight || 0 }
    ]}>
      <Text style={styles.title}>{title}</Text>
      
      <View style={styles.buttonsContainer}>
        {showSearch && (
          <TouchableOpacity 
            style={styles.iconButton} 
            onPress={onSearchPress}
            hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
          >
            <Search size={24} color="#18181B" />
          </TouchableOpacity>
        )}
        
        {showNotification && (
          <TouchableOpacity 
            style={styles.iconButton} 
            onPress={onNotificationPress}
            hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
          >
            <Bell size={24} color="#18181B" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
  },
  buttonsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    marginLeft: 16,
  },
});