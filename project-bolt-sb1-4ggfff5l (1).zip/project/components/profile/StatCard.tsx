import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Card from '../common/Card';
import { LucideIcon } from 'lucide-react-native';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBgColor?: string;
  description?: string;
}

export default function StatCard({ 
  title, 
  value, 
  icon,
  iconBgColor = '#E6F7EF',
  description,
}: StatCardProps) {
  return (
    <Card style={styles.container} variant="elevated">
      <View style={[styles.iconContainer, { backgroundColor: iconBgColor }]}>
        {icon}
      </View>
      
      <View style={styles.contentContainer}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.value}>{value}</Text>
        {description && <Text style={styles.description}>{description}</Text>}
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginVertical: 8,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  contentContainer: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    fontFamily: 'Manrope-Medium',
    color: '#71717A',
    marginBottom: 4,
  },
  value: {
    fontSize: 20,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
  },
  description: {
    fontSize: 12,
    fontFamily: 'Manrope-Regular',
    color: '#52525B',
    marginTop: 4,
  },
});