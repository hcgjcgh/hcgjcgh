import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import Svg, { Path, G, Line, Text as SvgText } from 'react-native-svg';

interface DataPoint {
  value: number;
  label: string;
}

interface ProgressChartProps {
  data: DataPoint[];
  title: string;
  color?: string;
}

export default function ProgressChart({ 
  data, 
  title,
  color = '#005F40' 
}: ProgressChartProps) {
  if (!data || data.length === 0) {
    return null;
  }

  const chartWidth = Dimensions.get('window').width - 48; // Accounting for padding
  const chartHeight = 200;
  const paddingHorizontal = 16;
  const paddingVertical = 24;
  
  const graphWidth = chartWidth - 2 * paddingHorizontal;
  const graphHeight = chartHeight - 2 * paddingVertical;

  // Find min and max values to scale the chart
  const maxValue = Math.max(...data.map(item => item.value));
  const minValue = 0; // Set to 0 for better visualization, or use Math.min for actual min
  
  // Scale data points to fit the chart
  const scaleY = (value: number) => {
    return paddingVertical + graphHeight - ((value - minValue) / (maxValue - minValue)) * graphHeight;
  };
  
  const scaleX = (index: number) => {
    return paddingHorizontal + (index / (data.length - 1)) * graphWidth;
  };
  
  // Generate path for the line
  let path = '';
  data.forEach((point, index) => {
    const x = scaleX(index);
    const y = scaleY(point.value);
    if (index === 0) {
      path += `M ${x} ${y}`;
    } else {
      path += ` L ${x} ${y}`;
    }
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      
      <Svg width={chartWidth} height={chartHeight}>
        {/* Grid lines */}
        <G>
          {[0, 0.25, 0.5, 0.75, 1].map((ratio, index) => {
            const y = paddingVertical + graphHeight * (1 - ratio);
            return (
              <React.Fragment key={index}>
                <Line
                  x1={paddingHorizontal}
                  y1={y}
                  x2={chartWidth - paddingHorizontal}
                  y2={y}
                  stroke="#E5E7EB"
                  strokeWidth="1"
                />
                <SvgText
                  x={paddingHorizontal - 5}
                  y={y + 4}
                  fontSize="10"
                  fontFamily="Manrope-Regular"
                  fill="#71717A"
                  textAnchor="end"
                >
                  {Math.round(minValue + ratio * (maxValue - minValue))}
                </SvgText>
              </React.Fragment>
            );
          })}
        </G>
        
        {/* Line chart */}
        <Path
          d={path}
          fill="none"
          stroke={color}
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        
        {/* Data points */}
        {data.map((point, index) => (
          <G key={index}>
            <SvgText
              x={scaleX(index)}
              y={chartHeight - 8}
              fontSize="10"
              fontFamily="Manrope-Regular"
              fill="#71717A"
              textAnchor="middle"
            >
              {point.label}
            </SvgText>
            <circle
              cx={scaleX(index)}
              cy={scaleY(point.value)}
              r="4"
              fill="#FFFFFF"
              stroke={color}
              strokeWidth="2"
            />
          </G>
        ))}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginTop: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
    marginBottom: 16,
  },
});