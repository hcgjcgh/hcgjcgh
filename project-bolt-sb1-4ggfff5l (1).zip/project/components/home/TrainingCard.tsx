import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ImageSourcePropType, Image } from 'react-native';
import { Clock, Zap } from 'lucide-react-native';

interface TrainingCardProps {
  title: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  image: ImageSourcePropType;
  onPress: () => void;
}

export default function TrainingCard({ 
  title, 
  duration, 
  level, 
  image, 
  onPress 
}: TrainingCardProps) {
  const levelColor = 
    level === 'Beginner' ? '#22C55E' : 
    level === 'Intermediate' ? '#F59E0B' : 
    '#EF4444';

  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.9}>
      <View style={styles.imageContainer}>
        <Image source={image} style={styles.image} />
      </View>
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={1}>{title}</Text>
        
        <View style={styles.metaContainer}>
          <View style={styles.metaItem}>
            <Clock size={14} color="#71717A" style={styles.icon} />
            <Text style={styles.metaText}>{duration}</Text>
          </View>
          
          <View style={styles.metaItem}>
            <Zap size={14} color={levelColor} style={styles.icon} />
            <Text style={[styles.metaText, { color: levelColor }]}>{level}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  imageContainer: {
    width: 80,
    height: 80,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  content: {
    flex: 1,
    padding: 12,
    justifyContent: 'center',
  },
  title: {
    fontSize: 16,
    fontFamily: 'Manrope-SemiBold',
    color: '#18181B',
    marginBottom: 4,
  },
  metaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
  },
  icon: {
    marginRight: 4,
  },
  metaText: {
    fontSize: 12,
    fontFamily: 'Manrope-Medium',
    color: '#71717A',
  },
});