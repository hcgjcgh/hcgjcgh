import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import Header from '@/components/common/Header';
import ProgressChart from '@/components/progress/ProgressChart';
import { progressData, userStats } from '@/constants/mockData';
import Card from '@/components/common/Card';
import { Timer, Flame, Award, Zap } from 'lucide-react-native';
import StatCard from '@/components/profile/StatCard';

export default function ProgressScreen() {
  return (
    <View style={styles.container}>
      <Header title="Progress" />
      
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.statsContainer}>
          <View style={styles.statsRow}>
            <StatCard 
              title="Total Sessions"
              value={userStats.totalSessions}
              icon={<Timer size={24} color="#005F40" />}
              iconBgColor="#E6F7EF"
            />
          </View>
          
          <View style={styles.statsRow}>
            <StatCard 
              title="Training Hours"
              value={userStats.totalHours}
              icon={<Award size={24} color="#FF6B00" />}
              iconBgColor="#FFF1E6"
            />
          </View>
          
          <View style={styles.statsRow}>
            <StatCard 
              title="Intensity"
              value={userStats.averageIntensity}
              icon={<Zap size={24} color="#F59E0B" />}
              iconBgColor="#FEF3C7"
            />
          </View>
          
          <View style={styles.statsRow}>
            <StatCard 
              title="Day Streak"
              value={userStats.daysStreak}
              icon={<Flame size={24} color="#EF4444" />}
              iconBgColor="#FEE2E2"
            />
          </View>
        </View>
        
        <ProgressChart 
          data={progressData} 
          title="Weekly Training Activity"
          color="#005F40"
        />
        
        <Card style={styles.summaryCard} variant="elevated">
          <Text style={styles.summaryTitle}>Weekly Summary</Text>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Total Distance</Text>
            <Text style={styles.summaryValue}>12.5 km</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Calories Burned</Text>
            <Text style={styles.summaryValue}>1,850 kcal</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Average Heart Rate</Text>
            <Text style={styles.summaryValue}>142 bpm</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Training Duration</Text>
            <Text style={styles.summaryValue}>4h 15m</Text>
          </View>
        </Card>
        
        <Card style={styles.goalsCard}>
          <Text style={styles.goalsTitle}>Weekly Goals</Text>
          <View style={styles.goalItem}>
            <View style={styles.goalInfo}>
              <Text style={styles.goalLabel}>Training Sessions</Text>
              <Text style={styles.goalProgress}>4 of 5</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: '80%' }]} />
            </View>
          </View>
          
          <View style={styles.goalItem}>
            <View style={styles.goalInfo}>
              <Text style={styles.goalLabel}>Endurance Training</Text>
              <Text style={styles.goalProgress}>2 of 3</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: '66%' }]} />
            </View>
          </View>
          
          <View style={styles.goalItem}>
            <View style={styles.goalInfo}>
              <Text style={styles.goalLabel}>Skill Development</Text>
              <Text style={styles.goalProgress}>3 of 4</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: '75%' }]} />
            </View>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingBottom: 80,
  },
  statsContainer: {
    marginTop: 16,
  },
  statsRow: {
    flex: 1,
  },
  summaryCard: {
    marginTop: 16,
    marginBottom: 16,
  },
  summaryTitle: {
    fontSize: 18,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
    marginBottom: 16,
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  summaryLabel: {
    fontSize: 14,
    fontFamily: 'Manrope-Medium',
    color: '#52525B',
  },
  summaryValue: {
    fontSize: 14,
    fontFamily: 'Manrope-SemiBold',
    color: '#18181B',
  },
  goalsCard: {
    marginBottom: 16,
  },
  goalsTitle: {
    fontSize: 18,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
    marginBottom: 16,
  },
  goalItem: {
    marginBottom: 16,
  },
  goalInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  goalLabel: {
    fontSize: 14,
    fontFamily: 'Manrope-Medium',
    color: '#52525B',
  },
  goalProgress: {
    fontSize: 14,
    fontFamily: 'Manrope-SemiBold',
    color: '#18181B',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#005F40',
    borderRadius: 4,
  },
});