import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from 'react-native';
import Header from '@/components/common/Header';
import { exercises, trainingPlans } from '@/constants/mockData';
import ExerciseCard from '@/components/training/ExerciseCard';
import TrainingPlanCard from '@/components/training/TrainingPlanCard';
import { Filter, ChevronRight } from 'lucide-react-native';
import { Link } from 'expo-router';

type FilterOption = 'all' | 'beginner' | 'intermediate' | 'advanced' | 'striker' | 'midfielder' | 'defender' | 'goalkeeper';

export default function TrainingScreen() {
  const [activeFilter, setActiveFilter] = useState<FilterOption>('all');
  
  const filterOptions: { value: FilterOption; label: string }[] = [
    { value: 'all', label: 'All' },
    { value: 'striker', label: 'Striker' },
    { value: 'midfielder', label: 'Midfielder' },
    { value: 'defender', label: 'Defender' },
    { value: 'goalkeeper', label: 'Goalkeeper' },
    { value: 'beginner', label: 'Beginner' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' },
  ];
  
  return (
    <View style={styles.container}>
      <Header title="Training" />
      
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Training Plans Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Training Plan</Text>
            <Link href="/training/plans" asChild>
              <TouchableOpacity style={styles.viewAllButton}>
                <Text style={styles.viewAllText}>View All</Text>
                <ChevronRight size={20} color="#005F40" />
              </TouchableOpacity>
            </Link>
          </View>
          
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.plansContainer}
          >
            {trainingPlans.map((plan) => (
              <TrainingPlanCard
                key={plan.id}
                title={plan.title}
                duration={plan.duration}
                level={plan.level}
                position={plan.position}
                progress={plan.progress}
                image={plan.image}
                onPress={() => {}}
              />
            ))}
          </ScrollView>
        </View>
        
        {/* Filters */}
        <View style={styles.filterContainer}>
          <View style={styles.filterHeader}>
            <Text style={styles.filterTitle}>Training Library</Text>
            <TouchableOpacity style={styles.filterButton}>
              <Filter size={20} color="#18181B" />
            </TouchableOpacity>
          </View>
          
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.tagsContainer}
          >
            {filterOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                style={[
                  styles.tagButton,
                  activeFilter === option.value && styles.activeTagButton,
                ]}
                onPress={() => setActiveFilter(option.value)}
              >
                <Text
                  style={[
                    styles.tagText,
                    activeFilter === option.value && styles.activeTagText,
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* Exercises Grid */}
        <View style={styles.exercisesGrid}>
          {exercises.map((exercise) => (
            <Link
              key={exercise.id}
              href={`/training/${exercise.id}`}
              asChild
              style={styles.exerciseCardContainer}
            >
              <TouchableOpacity>
                <ExerciseCard
                  title={exercise.title}
                  description={exercise.description}
                  image={exercise.image}
                  duration={exercise.duration}
                  onPress={() => {}}
                />
              </TouchableOpacity>
            </Link>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingBottom: 80,
  },
  section: {
    marginTop: 16,
    paddingHorizontal: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewAllText: {
    fontSize: 14,
    fontFamily: 'Manrope-SemiBold',
    color: '#005F40',
    marginRight: 4,
  },
  plansContainer: {
    paddingRight: 16,
  },
  filterContainer: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 16,
    marginTop: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  filterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  filterTitle: {
    fontSize: 20,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
  },
  filterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tagsContainer: {
    paddingRight: 8,
  },
  tagButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    marginRight: 8,
  },
  activeTagButton: {
    backgroundColor: '#005F40',
  },
  tagText: {
    fontSize: 14,
    fontFamily: 'Manrope-Medium',
    color: '#52525B',
  },
  activeTagText: {
    color: '#FFFFFF',
  },
  exercisesGrid: {
    padding: 16,
    ...Platform.select({
      web: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
        gap: 16,
      },
    }),
  },
  exerciseCardContainer: {
    ...Platform.select({
      ios: {
        width: '100%',
        marginBottom: 16,
      },
      android: {
        width: '100%',
        marginBottom: 16,
      },
    }),
  },
});