import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Settings, LogOut, Award, ChevronRight } from 'lucide-react-native';
import { achievements } from '@/constants/mockData';
import Card from '@/components/common/Card';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  
  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top }]}>
        <TouchableOpacity style={styles.iconButton}>
          <Settings size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton}>
          <LogOut size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.profileContainer}>
        <Image 
          source={{ uri: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg' }}
          style={styles.profileImage}
        />
        <Text style={styles.profileName}>Michael Jordan</Text>
        <Text style={styles.profileInfo}>Elite Level • Since 2023</Text>
      </View>
      
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>28</Text>
            <Text style={styles.statLabel}>Workouts</Text>
          </View>
          <View style={[styles.statItem, styles.statBorder]}>
            <Text style={styles.statValue}>12</Text>
            <Text style={styles.statLabel}>Hours</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>6</Text>
            <Text style={styles.statLabel}>Achievements</Text>
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>My Achievements</Text>
          
          {achievements.map((achievement) => (
            <Card key={achievement.id} style={styles.achievementCard} variant="elevated">
              <View style={styles.achievementHeader}>
                <View style={styles.achievementIcon}>
                  <Text style={styles.achievementIconText}>{achievement.icon}</Text>
                </View>
                <View style={styles.achievementContent}>
                  <Text style={styles.achievementTitle}>{achievement.title}</Text>
                  <Text style={styles.achievementDesc}>{achievement.description}</Text>
                </View>
                {achievement.completed ? (
                  <Award size={24} color="#005F40" />
                ) : (
                  <Text style={styles.achievementProgress}>{achievement.progress}%</Text>
                )}
              </View>
              
              {!achievement.completed && (
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: `${achievement.progress}%` }]} />
                </View>
              )}
            </Card>
          ))}
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>
          
          <Card style={styles.menuCard}>
            <TouchableOpacity style={styles.menuItem}>
              <Text style={styles.menuItemText}>Edit Profile</Text>
              <ChevronRight size={20} color="#71717A" />
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.menuItem}>
              <Text style={styles.menuItemText}>Notification Settings</Text>
              <ChevronRight size={20} color="#71717A" />
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.menuItem}>
              <Text style={styles.menuItemText}>Privacy Settings</Text>
              <ChevronRight size={20} color="#71717A" />
            </TouchableOpacity>
            
            <TouchableOpacity style={[styles.menuItem, { borderBottomWidth: 0 }]}>
              <Text style={styles.menuItemText}>Help & Support</Text>
              <ChevronRight size={20} color="#71717A" />
            </TouchableOpacity>
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 16,
    paddingBottom: 16,
    backgroundColor: '#005F40',
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileContainer: {
    alignItems: 'center',
    paddingBottom: 24,
    backgroundColor: '#005F40',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 4,
    borderColor: '#FFFFFF',
  },
  profileName: {
    fontSize: 24,
    fontFamily: 'Manrope-Bold',
    color: '#FFFFFF',
    marginTop: 12,
  },
  profileInfo: {
    fontSize: 14,
    fontFamily: 'Manrope-Medium',
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 4,
  },
  scrollView: {
    flex: 1,
    marginTop: -20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: '#F9FAFB',
  },
  content: {
    paddingBottom: 80,
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 16,
  },
  statBorder: {
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: '#F3F4F6',
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Manrope-Medium',
    color: '#71717A',
    marginTop: 4,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
    marginBottom: 16,
  },
  achievementCard: {
    marginBottom: 12,
  },
  achievementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  achievementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  achievementIconText: {
    fontSize: 20,
  },
  achievementContent: {
    flex: 1,
  },
  achievementTitle: {
    fontSize: 16,
    fontFamily: 'Manrope-SemiBold',
    color: '#18181B',
  },
  achievementDesc: {
    fontSize: 14,
    fontFamily: 'Manrope-Regular',
    color: '#52525B',
  },
  achievementProgress: {
    fontSize: 14,
    fontFamily: 'Manrope-SemiBold',
    color: '#005F40',
  },
  progressBar: {
    height: 4,
    backgroundColor: '#F3F4F6',
    borderRadius: 2,
    marginTop: 12,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#005F40',
    borderRadius: 2,
  },
  menuCard: {
    padding: 0,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  menuItemText: {
    fontSize: 16,
    fontFamily: 'Manrope-Medium',
    color: '#18181B',
  },
});