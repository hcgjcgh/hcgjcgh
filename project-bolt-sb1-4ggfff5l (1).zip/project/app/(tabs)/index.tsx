import React from 'react';
import { View, Text, StyleSheet, ScrollView, FlatList } from 'react-native';
import Header from '@/components/common/Header';
import FeaturedProgram from '@/components/home/FeaturedProgram';
import TrainingCard from '@/components/home/TrainingCard';
import Button from '@/components/common/Button';
import { featuredPrograms, popularTrainings, upcomingTrainings } from '@/constants/mockData';
import { Calendar, Clock } from 'lucide-react-native';

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <Header title="Football Pro" />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Featured Programs Carousel */}
        <FlatList
          data={featuredPrograms}
          renderItem={({ item }) => (
            <FeaturedProgram
              title={item.title}
              subtitle={item.subtitle}
              image={item.image}
              onPress={() => {}}
            />
          )}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.featuredContainer}
          snapToAlignment="start"
          snapToInterval={300}
          decelerationRate="fast"
          pagingEnabled
          style={styles.featuredList}
        />
        
        {/* Upcoming Training Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Upcoming Training</Text>
            <Button 
              title="View All" 
              variant="outline" 
              size="small" 
              onPress={() => {}}
            />
          </View>
          
          {upcomingTrainings.length > 0 ? (
            upcomingTrainings.map(training => (
              <View key={training.id} style={styles.upcomingCard}>
                <View style={styles.upcomingContent}>
                  <View style={styles.upcomingIconContainer}>
                    <Calendar size={24} color="#005F40" />
                  </View>
                  <View style={styles.upcomingInfo}>
                    <Text style={styles.upcomingTitle}>{training.title}</Text>
                    <Text style={styles.upcomingDate}>{training.date}</Text>
                  </View>
                </View>
                <View style={styles.upcomingMeta}>
                  <Clock size={14} color="#71717A" style={styles.upcomingIcon} />
                  <Text style={styles.upcomingDuration}>{training.duration}</Text>
                </View>
              </View>
            ))
          ) : (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No upcoming training sessions.</Text>
              <Button 
                title="Schedule Training" 
                variant="primary" 
                onPress={() => {}}
                style={styles.emptyButton}
              />
            </View>
          )}
        </View>
        
        {/* Popular Trainings Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Popular Trainings</Text>
            <Button 
              title="View All" 
              variant="outline" 
              size="small" 
              onPress={() => {}}
            />
          </View>
          
          {popularTrainings.map(training => (
            <TrainingCard
              key={training.id}
              title={training.title}
              duration={training.duration}
              level={training.level}
              image={training.image}
              onPress={() => {}}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 16,
    paddingBottom: 80,
  },
  featuredContainer: {
    paddingRight: 16,
  },
  featuredList: {
    marginLeft: -16,
    paddingLeft: 16,
    marginBottom: 16,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Manrope-Bold',
    color: '#18181B',
  },
  upcomingCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  upcomingContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  upcomingIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E6F7EF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  upcomingInfo: {
    flex: 1,
  },
  upcomingTitle: {
    fontSize: 16,
    fontFamily: 'Manrope-SemiBold',
    color: '#18181B',
    marginBottom: 4,
  },
  upcomingDate: {
    fontSize: 14,
    fontFamily: 'Manrope-Regular',
    color: '#52525B',
  },
  upcomingMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  upcomingIcon: {
    marginRight: 4,
  },
  upcomingDuration: {
    fontSize: 12,
    fontFamily: 'Manrope-Medium',
    color: '#71717A',
  },
  emptyContainer: {
    padding: 24,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Manrope-Medium',
    color: '#52525B',
    marginBottom: 16,
    textAlign: 'center',
  },
  emptyButton: {
    minWidth: 180,
  },
});