export const featuredPrograms = [
  {
    id: '1',
    title: 'Pro Striker Trainig',
    subtitle: 'Featured Program',
    image: { uri: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg' },
  },
  {
    id: '2',
    title: 'Midfield Mastery',
    subtitle: 'New Program',
    image: { uri: 'https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg' },
  },
];

export const trainingPlans = [
  {
    id: '1',
    title: 'Elite Striker Program',
    duration: '8 weeks',
    level: 'Advanced',
    position: 'Striker',
    progress: 65,
    image: { uri: 'https://images.pexels.com/photos/918798/pexels-photo-918798.jpeg' },
  },
  {
    id: '2',
    title: 'Midfield Maestro',
    duration: '6 weeks',
    level: 'Intermediate',
    position: 'Midfielder',
    progress: 30,
    image: { uri: 'https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg' },
  },
  {
    id: '3',
    title: 'Defensive Wall',
    duration: '4 weeks',
    level: 'Beginner',
    position: 'Defender',
    progress: 85,
    image: { uri: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg' },
  },
];

export const exercises = [
  {
    id: '1',
    title: 'Quick Feet Ladder Drill',
    description: 'Improve your foot speed and coordination with this essential ladder drill used by professional football players.',
    image: { uri: 'https://images.pexels.com/photos/8224158/pexels-photo-8224158.jpeg' },
    duration: '6:30',
    level: 'Beginner',
    category: 'Agility',
    equipment: ['Agility Ladder'],
    steps: [
      'Set up the agility ladder on a flat surface',
      'Start at one end of the ladder',
      'Perform high knees through each square',
      'Keep your upper body straight',
      'Land on the balls of your feet',
    ],
  },
  {
    id: '2',
    title: 'Cone Dribbling Challenge',
    description: 'Master the art of close ball control and quick direction changes with this effective cone dribbling drill.',
    image: { uri: 'https://images.pexels.com/photos/5778899/pexels-photo-5778899.jpeg' },
    duration: '8:45',
    level: 'Intermediate',
    category: 'Ball Control',
    equipment: ['Cones', 'Football'],
    steps: [
      'Place 6 cones in a zigzag pattern',
      'Start with the ball at the first cone',
      'Dribble through the cones using both feet',
      'Keep the ball close to your feet',
      'Increase speed as you improve',
    ],
  },
  {
    id: '3',
    title: 'Power Shot Training',
    description: 'Develop a more powerful and accurate shot with this targeted training routine focused on proper technique.',
    image: { uri: 'https://images.pexels.com/photos/258395/pexels-photo-258395.jpeg' },
    duration: '10:15',
    level: 'Advanced',
    category: 'Shooting',
    equipment: ['Football', 'Goal'],
    steps: [
      'Position the ball 20 yards from goal',
      'Focus on your plant foot placement',
      'Strike through the ball with laces',
      'Follow through with your shooting leg',
      'Aim for the corners of the goal',
    ],
  },
  {
    id: '4',
    title: 'High-Intensity Intervals',
    description: 'Build your stamina and match fitness with this high-intensity interval training session designed for footballers.',
    image: { uri: 'https://images.pexels.com/photos/3642533/pexels-photo-3642533.jpeg' },
    duration: '12:00',
    level: 'Advanced',
    category: 'Fitness',
    equipment: ['Cones'],
    steps: [
      'Set up two cones 20 meters apart',
      'Sprint between cones at maximum effort',
      'Walk back to starting position',
      'Repeat for specified intervals',
      'Maintain proper running form',
    ],
  },
];

export const userStats = {
  totalSessions: 28,
  totalHours: 22.5,
  averageIntensity: '75%',
  daysStreak: 6,
};

export const upcomingTrainings = [
  {
    id: '1',
    title: 'Speed Training',
    date: 'Today, 5:00 PM',
    duration: '45 min',
  },
  {
    id: '2',
    title: 'Shooting Practice',
    date: 'Tomorrow, 4:30 PM',
    duration: '60 min',
  },
];

export const achievements = [
  {
    id: '1',
    title: 'First Week Complete',
    description: 'Completed 7 days of training',
    icon: '🏆',
    completed: true,
  },
  {
    id: '2',
    title: 'Consistent Athlete',
    description: 'Trained for 10 consecutive days',
    icon: '🔥',
    completed: false,
    progress: 60,
  },
  {
    id: '3',
    title: 'Speed Demon',
    description: 'Completed all speed drills',
    icon: '⚡',
    completed: false,
    progress: 75,
  },
];

export const progressData = [
  { value: 35, label: 'Mon' },
  { value: 52, label: 'Tue' },
  { value: 45, label: 'Wed' },
  { value: 70, label: 'Thu' },
  { value: 65, label: 'Fri' },
  { value: 90, label: 'Sat' },
  { value: 55, label: 'Sun' },
];